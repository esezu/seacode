<?php
/**
 * 基于F3框架的影视资源聚合脚本
 * 所有功能整合到单个index.php文件中
 */

// 1. 引入F3框架
require __DIR__ . '/../fatfree-core-master/base.php';

// 2. 初始化F3实例
$f3 = \Base::instance();

// 3. 框架基础配置
$f3->set('DEBUG', 3);
$f3->set('UI', 'ui/');
$f3->set('CACHE', false);
$f3->set('TEMP', 'tmp/');
$f3->set('ESCAPE', false);

// 4. 全局配置（使用F3配置管理）
$f3->set('SITE_NAME', '影视资源');
$f3->set('SITE_DOMAIN', 'demo.test');
$f3->set('SITE_EMAIL', 'admin@admin.com');

$f3->set('API_URL_1', '豪华资源#https://hhzyapi.com/api.php/provide/vod/at/xml');
$f3->set('API_URL_2', '无尽资源#https://api.wujinapi.me/api.php/provide/vod/from/wjm3u8/at/xml/');
$f3->set('API_URL_3', '红牛资源#https://www.hongniuzy2.com/api.php/provide/vod/at/xml/');
$f3->set('API_URL_4', '如意资源#https://cj.rycjapi.com/api.php/provide/vod/at/xml/');

$f3->set('VIDEO_PARSER', 'https://hhjiexi.com/play/?url=');
$f3->set('CACHE_HOURS', 1);
$f3->set('TEMPLATE_NAME', 'default');
$f3->set('SORT_DESC', 'yes');
$f3->set('SHOW_TIME_LIMIT', '');

// 5. SEO模板配置
$f3->set('SEO_TITLE', [
    'list' => '{{@CURRENT_CATEGORY}} - {{@SITE_NAME}}',
    'search' => '{{@SEARCH_KEYWORD}}的搜索结果 - {{@SITE_NAME}}',
    'info' => '{{@VIDEO_NAME}} - {{@SITE_NAME}}'
]);
$f3->set('SEO_KEYWORDS', [
    'list' => '{{@CURRENT_CATEGORY}},最新电影,最新电视,最新综艺,最新动漫',
    'search' => '{{@SEARCH_KEYWORD}},最新电影,最新电视,最新综艺,最新动漫',
    'info' => '{{@VIDEO_NAME}},最新电影,最新电视,最新综艺,最新动漫'
]);
$f3->set('SEO_DESCRIPTION', [
    'list' => '{{@SITE_NAME}}提供最新的电影、电视、综艺、动漫在线播放服务',
    'search' => '{{@SITE_NAME}}提供{{@SEARCH_KEYWORD}}的在线播放服务',
    'info' => '{{@SITE_NAME}}提供{{@VIDEO_NAME}}的在线播放服务'
]);

// 6. 初始化目录
$cacheDirs = [
    './tmp/data',
    './tmp/data/html',
    './tmp/data/list',
    './tmp/data/info',
    './tmp/data/search',
    './tmp/data/category',
    './tmp/data/dat'
];
foreach ($cacheDirs as $dir) {
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
}

// 7. 核心工具方法

/**
 * 模拟国内IP生成X-Forwarded-For请求头
 * 使用F3的\Web::request()发送GET请求（替换原生cURL所有逻辑）
 */
function fetchAPI($url) {
    $ip_long = array(array('607649792', '608174079'), array('1038614528', '1039007743'), array('1783627776', '1784676351'), array('2035023872', '2035154943'), array('2078801920', '2079064063'), array('-1950089216', '-1948778497'), array('-1425539072', '-1425014785'), array('-1236271104', '-1235419137'), array('-770113536', '-768606209'), array('-569376768', '-564133889'));
    $rand_key = mt_rand(0, 9);$ips = long2ip(mt_rand($ip_long[$rand_key][0], $ip_long[$rand_key][1]));
    $headers = ['X-Forwarded-For: ' . $ips, 'User-Agent: ' . ($_SERVER['HTTP_USER_AGENT'] ?? 'Mozilla/5.0 (Unknown; Linux x86_64) AppleWebKit/537.36')];
    $options = ['method' => 'GET', 'header' => $headers, 'encoding' => 'gzip', 'timeout' => 30];
    
    try {
        $web = \Web::instance();
        $response = $web->request($url, $options);
        return $response['body'];
    } catch (Exception $e) {
        $f3 = \Base::instance();
        $f3->error("F3 curl请求失败：" . $e->getMessage());
        return false;
    }

}

function handleDataCache($sort, $id, $page, $clearCache = false) {
    $f3 = \Base::instance();
    
    if ($clearCache) {
        $cacheDir = './tmp/data';
        if (is_dir($cacheDir)) {
            $files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($cacheDir, RecursiveDirectoryIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST);
            foreach ($files as $file) {
                if ($file->isDir()) {
                    @rmdir($file->getPathname());
                } else {
                    @unlink($file->getPathname());
                }
            }
        }
        return [];
    }
    
    $defaultApiConfig = $f3->get('API_URL_1');
    list($defaultApiName, $defaultApiUrl) = explode('#', $defaultApiConfig);
    $apiUrl = $f3->get('CURRENT_API_URL', $defaultApiUrl);
    $showTimeLimit = $f3->get('SHOW_TIME_LIMIT');
    $cacheHours = $f3->get('CACHE_HOURS');
    $sortDesc = $f3->get('SORT_DESC');
    $cacheTtl = $cacheHours * 3600;
    
    $cacheDir = './tmp/data/' . $sort . '/';
    if (!is_dir($cacheDir)) {
        mkdir($cacheDir, 0755, true);
    }
    
    $actualPage = $page;
    $cacheFile = $cacheDir . md5($id) . '-' . $actualPage . '.txt';
    
    if (file_exists($cacheFile) && (time() - filemtime($cacheFile)) < $cacheTtl) {
        $data = file_get_contents($cacheFile);
        return json_decode($data, true);
    }
    
    $requestUrl = '';
    switch ($sort) {
        case 'category':
            $requestUrl = $apiUrl . '?ac=list';
            break;
        case 'info':
            $requestUrl = $apiUrl . '?ac=videolist&ids=' . $id . $showTimeLimit;
            break;
        case 'search':
            $requestUrl = $apiUrl . '?ac=videolist&wd=' . urlencode($id) . '&pg=' . $page . $showTimeLimit;
            break;
        case 'list':
            $pageCountFile = './tmp/data/dat/' . md5($id) . '-pagz.txt';
            if (!is_dir('./tmp/data/dat/')) {
                mkdir('./tmp/data/dat/', 0755, true);
            }
            
            $pageCount = 1;
            if (file_exists($pageCountFile)) {
                $pageCount = (int)file_get_contents($pageCountFile);
            } else {
                $pageUrl = $apiUrl . '?ac=videolist&&t=' . $id . '&pg=' . $page . $showTimeLimit;
                $pageContent = fetchAPI($pageUrl);
                preg_match('/pagecount="(\d+)"/', $pageContent, $matches);
                $pageCount = $matches[1] ?? 1;
                file_put_contents($pageCountFile, $pageCount);
            }
            
            if ($sortDesc === 'yes') {
                $actualPage = $pageCount - $page + 1;
            }
            $requestUrl = $apiUrl . '?ac=videolist&&t=' . $id . '&pg=' . $actualPage . $showTimeLimit;
            break;
    }
    
    $remoteData = fetchAPI($requestUrl);
    if (empty($remoteData)) {
        return [];
    }
    
    // 分类数据特殊处理
    if ($sort === 'category') {
        $xml = simplexml_load_string($remoteData);
        if ($xml === false) {
            return [];
        }
        
        $categories = [];
        $categories[] = ['分类号' => '', '分类名' => '最近更新'];
        
        if (isset($xml->class->ty)) {
            foreach ($xml->class->ty as $ty) {
                $categories[] = ['分类号' => (string)$ty['id'], '分类名' => (string)$ty];
            }
        }
        
        $cleanJson = json_encode($categories, JSON_UNESCAPED_UNICODE);
    } else {
        $cleanData = preg_replace('/<script(.*?)<\/script>|<span[^>]*?>|<\/span>|<p\s[^>]*?>|<p>|<\/p>/i', '', $remoteData);
        
        $xml = simplexml_load_string($cleanData, 'SimpleXMLElement', LIBXML_NOCDATA);
        if ($xml === false) {
            return [];
        }
        
        $xmlArray = json_decode(json_encode($xml), true);
        $cleanJson = json_encode($xmlArray);
        
        // 保留flag属性，只删除其他不必要的@attributes和空对象
        $cleanJson = preg_replace('/(?:,\{"@attributes":\{(?!.*"flag")[^}]*\}\}|\{"@attributes":\{(?!.*"flag")[^}]*\}\},)/', '', $cleanJson);
        $cleanJson = preg_replace('/,"([^"]*?)":\{(?:\{"0":""\}|\{\})/', '', $cleanJson);
        $cleanJson = str_replace(['" "'], ['""'], $cleanJson);
    }
    
    if (strlen($cleanJson) > 50) {
        file_put_contents($cacheFile, $cleanJson);
        
        if ($sort === 'list') {
            $listData = json_decode($cleanJson, true);
            $videos = $listData['list']['video'] ?? [];
            foreach ($videos as $video) {
                if (!empty($video['id'])) {
                    $infoCacheDir = './tmp/data/info/';
                    if (!is_dir($infoCacheDir)) {
                        mkdir($infoCacheDir, 0755, true);
                    }
                    $infoCacheFile = $infoCacheDir . $video['id'] . '-1.txt';
                    $infoData = json_encode(['list' => ['video' => $video]]);
                    file_put_contents($infoCacheFile, $infoData);
                }
            }
        }
    }
    
    return json_decode($cleanJson, true);
}

/**
 * 构建页面URL
 */
function buildPageUrl($sort, $id = '', $page = 1)
{
    $params = [];
    switch ($sort) {
        case 'list':
            $params['sort'] = $id;
            $params['page'] = $page;
            break;
        case 'search':
            $params['key'] = $id;
            $params['page'] = $page;
            break;
        case 'info':
            $params['info'] = $id;
            break;
    }
    
    $f3 = \Base::instance();
    return $f3->get('BASE') . '?' . http_build_query($params);
}

// 8. 定义F3路由
$f3->route('GET /', function($f3) {
    $infoId = $_GET['info'] ?? null;
    $searchKey = $_GET['key'] ?? null;
    $sortId = $_GET['sort'] ?? null;
    $page = max(1, (int)($_GET['page'] ?? 1));
    $apiSelect = $_COOKIE['api_select'] ?? '1';
    
    $pageType = 'list';
    $uniqueId = $sortId ?? '';
    if (!empty($infoId)) {
        $pageType = 'info';
        $uniqueId = $infoId;
    } elseif (!empty($searchKey)) {
        $pageType = 'search';
        $uniqueId = urldecode($searchKey);
    }
    
    $lastApi = $_COOKIE['last_api'] ?? '';
    if ($lastApi && $lastApi !== $apiSelect) {
        handleDataCache('', '', 1, true);
    }
    setcookie('last_api', $apiSelect, time() + 86400 * 30, '/');
    setcookie('api_select', $apiSelect, time() + 86400 * 30, '/');
    
    $defaultApiConfig = $f3->get('API_URL_1');
    list($defaultApiName, $defaultApiUrl) = explode('#', $defaultApiConfig);
    
    $apiConfig = $f3->get('API_URL_' . $apiSelect);
    if ($apiConfig) {
        list($apiName, $apiUrl) = explode('#', $apiConfig);
        $f3->set('CURRENT_API_NAME', $apiName);
        $f3->set('CURRENT_API_URL', $apiUrl);
    } else {
        $f3->set('CURRENT_API_NAME', $defaultApiName);
        $f3->set('CURRENT_API_URL', $defaultApiUrl);
    }
    
    $f3->set('CURRENT_API', $apiSelect);
    
    $apiList = [];
    $i = 1;
    while (true) {
        $config = $f3->get('API_URL_' . $i);
        if (!$config) {
            break;
        }
        list($name, $url) = explode('#', $config);
        $apiList[] = ['id' => $i, 'name' => $name, 'url' => $url];
        $i++;
    }
    $f3->set('API_LIST', $apiList);
    
    $categories = handleDataCache('category', '', 1);
    $f3->set('CATEGORIES', $categories);
    
    $videoData = handleDataCache($pageType, $uniqueId, $page);
    
    if ($pageType === 'info') {
        $f3->set('VIDEO_DATA', []);
        $videoInfo = $videoData['list']['video'] ?? [];
        // 保留原始的dl数据结构，供JS使用
        if (!isset($videoInfo['dl'])) {
            $videoInfo['dl'] = ['dd' => ''];
        }
         
         // 在PHP端处理播放源，优先使用m3u8的播放源
         $dlData = $videoInfo['dl']['dd'] ?? [];
         $selectedDd = null;
         
         if (is_array($dlData)) {
             foreach ($dlData as $ddItem) {
                 if (is_string($ddItem)) {
                     // 检查是否包含m3u8
                     if (stripos($ddItem, 'm3u8') !== false) {
                         $selectedDd = $ddItem;
                         break;
                     }
                 } elseif (isset($ddItem['@attributes']['flag'])) {
                     // 检查flag是否包含m3u8
                     if (stripos($ddItem['@attributes']['flag'], 'm3u8') !== false) {
                         $selectedDd = $ddItem;
                         break;
                     }
                 }
             }
             // 如果没有找到m3u8，使用第一个播放源
             if ($selectedDd === null && !empty($dlData)) {
                 $selectedDd = $dlData[0];
             }
         }
         
         // 使用选中的播放源
         if ($selectedDd !== null) {
             $videoInfo['dl']['dd'] = is_array($selectedDd) ? [$selectedDd] : $selectedDd;
         }
         
         // 生成JavaScript代码（压缩成一行）
         $videoParser = $f3->get('VIDEO_PARSER');
         $jsCode = "<script>var bflist=" . json_encode($videoInfo['dl']) . ";var jx='" . $videoParser . "';function bf(str){document.getElementById(\"iframe\").style.display=\"block\";document.getElementById(\"frame\").src=jx+str;}if(Array.isArray(bflist['dd'])){var viddz=bflist['dd'];}else{var viddz=new Array(bflist['dd']);}var bfmoban=document.getElementById(\"playlist\").innerHTML;document.getElementById(\"playlist\").innerHTML='';for(var i in viddz){viddz[i]=viddz[i].split(\"#\");for(var k=0;k<viddz[i].length;k++){viddz[i][k]=viddz[i][k].split(\"$\");if(viddz[i][k][2]==undefined){var zyname='yun';}else{var zyname=viddz[i][k][2];}if(k=='0'){document.getElementById(\"playlist\").innerHTML+=bfmoban.replace(/资源加载中/g,zyname);var jjmoban=document.getElementById(\"zylx\"+zyname).innerHTML;var bfnr='';}bfnr=bfnr+jjmoban.replace(/剧集加载中/g,viddz[i][k][0]).replace(/剧集地址加载中/g,viddz[i][k][1]);}document.getElementById(\"zylx\"+zyname).innerHTML=bfnr;}</script>";
         $f3->set('PLAYER_SCRIPT', $jsCode);

        $f3->set('VIDEO_INFO', $videoInfo);
    } else {
        $videoList = $videoData['list']['video'] ?? [];
        $f3->set('VIDEO_DATA', $videoList);
    }
    
    $pagination = ['current' => $page, 'prev' => 1, 'next' => 1, 'last' => 1, 'first' => ''];
    
    if (!empty($videoData['list']['@attributes']['pagecount'])) {
        $pageCount = (int)$videoData['list']['@attributes']['pagecount'];
        $pagination['last'] = $pageCount;
        $pagination['prev'] = max(1, $page - 1);
        $pagination['next'] = min($pageCount, $page + 1);
    }
    
    $pagination['firstUrl'] = buildPageUrl($pageType, $uniqueId, 1);
    $pagination['prevUrl'] = buildPageUrl($pageType, $uniqueId, $pagination['prev']);
    $pagination['nextUrl'] = buildPageUrl($pageType, $uniqueId, $pagination['next']);
    $pagination['lastUrl'] = buildPageUrl($pageType, $uniqueId, $pagination['last']);
    $f3->set('PAGINATION', $pagination);
    
    $seoData = ['CURRENT_CATEGORY' => '最近更新', 'SEARCH_KEYWORD' => '', 'VIDEO_NAME' => ''];
    
    if ($pageType === 'search') {
        $seoData['SEARCH_KEYWORD'] = $uniqueId;
    }
    
    if ($pageType === 'list') {
        foreach ($categories as $cate) {
            if ($cate['分类号'] == $uniqueId) {
                $seoData['CURRENT_CATEGORY'] = $cate['分类名'];
                break;
            }
        }
    }
    
    if ($pageType === 'info' && !empty($f3->get('VIDEO_DATA'))) {
        $videoInfo = $f3->get('VIDEO_DATA')[0] ?? [];
        $seoData['VIDEO_NAME'] = $videoInfo['name'] ?? '';
        $f3->set('VIDEO_INFO', $videoInfo);
    }
    
    foreach ($seoData as $key => $value) {
        $f3->set($key, $value);
    }
    
    $f3->set('VIDEO_PARSER', $f3->get('VIDEO_PARSER'));
    $f3->set('BASE', $f3->get('SCHEME') . '://' . $f3->get('HOST') . ':' . $f3->get('PORT'));
    
    $templateName = $f3->get('TEMPLATE_NAME');
    $uiPath = $f3->get('UI');
    $templatePath = $uiPath . $templateName;
    $f3->set('TEMPLATE_PATH', $templatePath);
    
    if ($pageType === 'info') {
        $f3->set('TEMPLATE_TO_INCLUDE', $templateName . '/info.html');
    } elseif ($pageType === 'search') {
        $f3->set('TEMPLATE_TO_INCLUDE', $templateName . '/search.html');
    } else {
        $f3->set('TEMPLATE_TO_INCLUDE', $templateName . '/list.html');
    }
    
    echo \Template::instance()->render($templateName . '/indexs.html');
});

// 9. 运行F3应用
$f3->run();